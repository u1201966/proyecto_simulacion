﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class controlador_nuevo : MonoBehaviour
{
    public float velocidad, g=9.8f; //variable que depende de si se presiona o no la tecla espacio. Determina la velocidad a la que se mueve el objeto.
    public GameObject gaancho; //objeto del gancho. a futuro se aspira a trabajarlo con una animación del modelo.
    public GameObject[] esquinas;
    public Vector3 posicion_dron;
    public GameObject dronn;
    public GameObject camara;
    public GameObject completo;
    public GameObject apuntador;
    public float vy = 0;
    public float vx = 0;
    public float i1,i2,d1,d2;
    bool bloqueoY = false; //utilizada para bloquear la altura del dron
    int vaGancho = 0; //Variable de control para los estados de agarrar y soltar el gancho
    float e = 1f;
    float escalaGancho = 0;
    public float dx = 0, dz = 0;
    //variables para verificar si se está o no agarrando objeto
    public List<GameObject> objs = cajas.objetos; //Nótese que son objetos instanciados, lo que abre posibilidades para más adelante
    public GameObject caj = cajas.caja;
    public float cajangulo, ladocaja = 0.5f, colision = 0, M1 = 1, M2 = 5;
    Vector3 posicion;
    //finaliza variables agarrar objet
    //empiezan variables fuerza del viento
    public float fv;
    public Vector3 dirv;
    public Vector3 torq;
    public Vector3 dist;
    Vector3 velocidad_angular;
    Vector3 aceleracion_angular;
    float angulo_a_rotar;
    float momento_de_inercia;
    //finalizan variables del viento
    // Start is called before the first frame update
    void Start()
    {
        escalaGancho = 0.25f;
        posicion = transform.position;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //leer valor de viento
        fv = viento.fuerza_viento;
        dirv = viento.direccion_viento;
        torq = viento.torque;
        dist = viento.distancia_centro_a_punto;
        //finaliza valor de viento
        posicion = gaancho.gameObject.GetComponent<Transform>().position; //con esta posición es que se realiza la comparación de posiciones para agarrar un objeto
        //Verificación de si se quiere bloquear la altura
        if (Input.GetMouseButtonDown(1))
        {
            if (bloqueoY == false)
            {
                bloqueoY = true;
            }
            //cuando se pregunta por si se presiona o no el mouse es menester colocarlo directamente en el Update por ello no se puso en una función aparte
            else
            {
                bloqueoY = false;
            }
        }
        //Finaliza verificación de si sequiere bloquear la altura

        golpe();
        CalculoVelocidad();
        MovimientoPersonaje();


        gravedad();
        //Empieza agarrar objeto.
        if (Input.GetMouseButtonUp(0))
        {
            GanchoObjeto();
        }

        if (vaGancho == 1)
        {
            //Si ya se presionó el botón y el estado de gancho era cero, entonces empezará a desplegar la animación del gancho
            escalaGancho += 0.3f;
            escalaGancho = Mathf.Clamp(escalaGancho, 0, 6);
            gaancho.transform.localScale = new Vector3(0.22f, escalaGancho, 0.22f);
            //se verifica si está o no tocando alguna caja
            foreach (GameObject caj in objs)
            {
                Vector3 posicion_caja = caj.gameObject.GetComponent<Transform>().position;
                //Debug.Log("La posicion de Obj es: " + caj.gameObject.GetComponent<Transform>().position + " Mientras que la de posicion caja es :" + posicion_caja );
                if (posicion.y - posicion_caja.y <= 6 && Mathf.Abs(posicion.x - posicion_caja.x) <= 1 && Mathf.Abs(posicion.z - posicion_caja.z) <= 1)
                {
                    //Debug.Log("¡La agarró! y la posicion es " + posicion_caja + " Y la del dron es :" + posicion);
                    caj.gameObject.tag = "agarrado";
                }
            }
            //Finaliza verificación de agarrar o no objeto
            Debug.Log("Está bajando");
        }
        if (vaGancho == 2)
        {
            escalaGancho -= 0.3f;
            escalaGancho = Mathf.Clamp(escalaGancho, 0, 6);
            gaancho.transform.localScale = new Vector3(0.22f, escalaGancho, 0.22f);
            if (escalaGancho <= 0)
            {
                vaGancho = 0;
            }
            Debug.Log("Está subiendo.");
            SoltarObjeto();
        }
        //Finaliza agarrar objeto.
        //empieza movimiento de la caja agarrada
        MoverAgarrado();
        //finaliza movimiento de la caja agarrada
        //EMPIEZA afección por el viento (dado el caso)
        if (fv != 0)
        {
            //Debug.Log("La posición antes de entrar a la corriente es: " + posicion_dron);
            posicion_dron.x = posicion_dron.x - (dirv.x * fv * 0.5f);
            posicion_dron.y = posicion_dron.y - (dirv.y * fv * 0.5f);
            posicion_dron.z = posicion_dron.z - (dirv.z * fv * 0.5f);
            //Debug.Log("La posición luego de entrar a la corriente es: " + posicion_dron);
            transform.Translate(posicion_dron, Space.Self);
            //Se empieza a rotar dado el torque
            Vector3 vector_fuerza_viento = new Vector3(dirv.x * fv, dirv.y * fv, dirv.z * fv);
            momento_de_inercia = (0.4f) * 2 * dist.magnitude; //El dos representa la masa del dron, cálculo del momento de incercia
            momento_de_inercia = Mathf.Clamp(momento_de_inercia, 0.01f, 40);
            aceleracion_angular += new Vector3(torq.x / momento_de_inercia, torq.y / momento_de_inercia, torq.z / momento_de_inercia);
            if (velocidad_angular.x <= 20 && velocidad_angular.y <= 20 && velocidad_angular.z <= 20)
            {
                velocidad_angular = new Vector3(velocidad_angular.x + aceleracion_angular.x, velocidad_angular.y + aceleracion_angular.y, velocidad_angular.z + aceleracion_angular.z);
            }
            Quaternion rotacion_viento_1 = Quaternion.AngleAxis(velocidad_angular.magnitude * 0.5f, Vector3.Cross(dist, dirv).normalized);
            dronn.gameObject.GetComponent<Transform>().rotation *= rotacion_viento_1;
            gaancho.gameObject.GetComponent<Transform>().rotation *= rotacion_viento_1;          
            //finaliza rotación dado un torque
        }
        else
        {
            dronn.transform.Rotate(0.05f * dirv.x, 0.05f * dirv.y, 0.05f * dirv.z, Space.Self);
        }
        //FINALIZA afección por el viento
        //Una vez hechos los posibles cambios sobre la posición del objeto, se procede, finalmente a actualizar la misma
        //camara.transform.Translate(posicion_dron,Space.Self);
        completo.transform.Translate(posicion_dron, Space.Self);
        dronn.GetComponent<Transform>().position = completo.GetComponent<Transform>().position;
        gaancho.gameObject.GetComponent<Transform>().position = transform.position;
        //finaliza actualización del objeto.
    }
    void SoltarObjeto()
    {
        foreach (GameObject caj in objs)
        {
            if (caj.gameObject.tag == "agarrado")
            {
                caj.gameObject.tag = "Untagged";
            }
        }
    }

    void MoverAgarrado()
    {
        foreach (GameObject caj in objs)
        {
            if (caj.gameObject.tag == "agarrado")
            {
                Vector3 posicion_caja = caj.gameObject.GetComponent<Transform>().position;
                caj.gameObject.GetComponent<Transform>().position = new Vector3(posicion.x, posicion.y - 1, posicion.z);
            }
        }
    }


    //Controlador estilo clic
    void GanchoObjeto()
    {
        if (vaGancho == 0)
        {
            vaGancho = 1;
        }
        else
        {
            vaGancho = 2;
        }
    }



    void CalculoVelocidad()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            if (hEntra != 0 || vEntra != 0)
            {
                ctrl = 1;
                if (velocidad < 5)
                {
                    velocidad += 0.1f;
                }
                else
                {
                    velocidad = 5;
                }
            }
        }

        if (hEntra == 0 && vEntra == 0)
        {
            if (velocidad > 0)
            {
                velocidad -= 0.1f;
            }
            else
            {
                velocidad = 0;
            }
        }
    }

    Vector3[] lados = new Vector3[4];
    void golpe()
    {
        float def_distance = Mathf.Sqrt(2f);
        float Pdistance, i, ag, min, angulo, Vp, V1x, V1z, Vn, Vc1, Vc1x, Vc1y, Vc2, Vc2x, Vc2y;
        int id = 0;
        foreach (GameObject caj in objs)
        {
            Vector3 posicion_caja = caj.gameObject.GetComponent<Transform>().position;
            Vector3 posicion_punto;

            if (Mathf.Abs((posicion - posicion_caja).magnitude) <= Mathf.Sqrt(2f)) //capa de verificacion de colision 1
            {
                //Debug.Log(Mathf.Abs((posicion - posicion_caja).magnitude)); 

                for (int d = 0; d < 4; d++)
                {
                    Pdistance = (Mathf.Abs((esquinas[d].gameObject.GetComponent<Transform>().position - posicion_caja).magnitude));
                    if (Pdistance < 1f)
                    {
                        colision = 1;
                    }
                    else
                       if (Pdistance < def_distance)
                    {
                        def_distance = Pdistance;
                        id = d;
                    }
                }
                if (colision == 0)
                {
                    posicion_punto = esquinas[id].gameObject.GetComponent<Transform>().position;
                    cajangulo = caj.transform.rotation.eulerAngles.y;//le da el angulo en y
                    posicion_punto.x = posicion_punto.x * Mathf.Cos(cajangulo) + posicion_punto.z * Mathf.Sin(cajangulo);
                    posicion_punto.z = -posicion_punto.x * Mathf.Sin(cajangulo) + posicion_punto.z * Mathf.Cos(cajangulo);
                    dx = Mathf.Abs(posicion_punto.x - posicion_caja.x);
                    dz = Mathf.Abs(posicion_punto.z - posicion_caja.z);
                    if (posicion_punto.z < posicion_caja.z + ladocaja && posicion_punto.z > posicion_caja.z - ladocaja)
                    {
                        ag = Mathf.Atan(dz / dx);
                    }
                    else
                        ag = Mathf.Atan(dx / dz);

                    min = ladocaja * 1 / Mathf.Cos(ag);

                    if (def_distance < min)
                    {
                        colision = 1;
                    }

                }

            }
        }
        if (colision == 1)
        {


            angulo = gameObject.GetComponent<Transform>().rotation.eulerAngles.y;
            Vp = velocidad;
            Vc1 = ((M1 - e * M2) / (M1 + M2)) * Vp; // velocidad resultante de la colision, en direccion del angulo (sentido opuesto)           
            Vc2 = (((1 + e) * M1) / (M1 + M2));// velocidad resultante de la colision para caja, en direccion del angulo (sentido opuesto)
            velocidad = Vc1;
            bloqueoY = false;
            colision = 0;


        }


    }



    float tg = 0, vr, vd = 0,gradosx, gradosx0=0, gradosz = 0;
    void gravedad()
    {
        float pos;
        if (posicion.y <= 0.5f)
        {
            posicion_dron.y = 0;
            tg = 0;

        }
       
        if (ctrl == 1 || bloqueoY == true || Input.GetKey(KeyCode.Space))
        {
            tg = 1;
            if (posicion.y <= 0.5f && vy <= 9.8f)
            {
                tg = 0;
            }
            if (bloqueoY == true || Input.GetKey(KeyCode.Space))
            {
                vy = 9.8f;
            }


        }

        vr = vy - g * tg;
        pos = vr * Time.deltaTime;
        posicion_dron.y = pos + posicion_dron.y;
        tg += Time.deltaTime;



        if (ctrl == 0 && bloqueoY == false && !Input.GetKey(KeyCode.Space))
        {
            if (vy < 1 && vy > -1)
            {
                vy = 0;
            }
            else
            {
                if (vy > 0)
                {
                    vy += -1;

                }
                else
                {
                    vy += 1;
                }
            }


        }

    }

    int ctrl = 0;
    float vz = 0;
    float hEntra = 0;
    float vEntra = 0;

    void MovimientoPersonaje()
    {
        ctrl = 0;
        //Empieza movimiento del dron en el plano X,Z.
        hEntra = Input.GetAxis("Horizontal");
        vEntra = Input.GetAxis("Vertical");

        gradosx = hEntra*57.29f;
        gradosz = vEntra * 57.29f;



        if (gradosx != 0 || Input.GetKey(KeyCode.W))//frente
        {
            ctrl = 1;
            vr = Mathf.Sqrt(vEntra * velocidad * vEntra * velocidad + 9.8f * 9.8f);
            vx = Mathf.Sin(gradosx) * vr;

            i1 = vr / 6;
            d1 = vr / 6;
            i2 = vr / 3;
            d2 = vr / 3;            
        }
        else if (gradosx != 0 || Input.GetKey(KeyCode.S))//atras
        {
            ctrl = 1;
            vr = Mathf.Sqrt(vEntra * velocidad * vEntra * velocidad + 9.8f * 9.8f);
            vx = Mathf.Sin(gradosx) * vr;
            i2 = vr / 6;
            d2 = vr / 6;
            i1 = vr / 3;
            d1 = vr / 3;
        }
        else if (gradosz != 0 || Input.GetKey(KeyCode.D))//derecha
        {
            ctrl = 1;       
            vr = Mathf.Sqrt( hEntra * velocidad* hEntra * velocidad+9.8f*9.8f);
            vx = Mathf.Sin(gradosz) * vr;            
            d1 = vr / 6;
            d2 = vr / 6;
            i1 = vr / 3;
            i2 = vr / 3;
        }
        else if (gradosz != 0 || Input.GetKey(KeyCode.A))//izquierda
        {
            ctrl = 1;
            vr = Mathf.Sqrt(hEntra * velocidad * hEntra * velocidad + 9.8f * 9.8f);
            vx = Mathf.Sin(gradosz) * vr;
            i1 = vr / 6;
            i2 = vr / 6;
            d1 = vr / 3;
            d2 = vr / 3;
        }

       

        dronn.transform.Rotate(vEntra* 57.29f, 0, -hEntra* 57.29f);
        posicion_dron = new Vector3(hEntra, 0, vEntra) * velocidad * Time.fixedDeltaTime;

        //Finaliza movimiento del dron en el plano X,Z.




        //Empieza elevación o descenso del dron (eje Y)
       
        if (bloqueoY == false && ctrl==0)
        {
            if (Input.GetKey(KeyCode.Z)) //tecla Z para ir arriba
            {
                if (vy < 20)
                {
                    vy += 1f;
                }                
                ctrl = 1;
            }
            if (Input.GetKey(KeyCode.X)) //tecla X para ir abajo
            {
                foreach (GameObject caj in objs)
                {
                    if (posicion.y >= 0.4)
                    {
                        if (vy > 5)
                        {
                            vy += -1;
                        }
                        else
                        {
                            vy = 5;
                        }
                        ctrl = 1;
                    }
                }
            }
            i1 = vy / 4;
            i2 = vy / 4;
            d1 = vy / 4;
            d2 = vy / 4;
        }
        //Finaliza elevación o descendo del dron (eje Y)

        //Helices y velocidad la variable vr es el 100 porciento de la velocidad del dron
        //i1;
        //i2;
        //d1;
        //d2;
    }
}
