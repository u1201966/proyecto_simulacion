﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class controlador_nuevo : MonoBehaviour
{
    public float velocidad; //variable que depende de si se presiona o no la tecla espacio. Determina la velocidad a la que se mueve el objeto.
    public GameObject gaancho; //objeto del gancho. a futuro se aspira a trabajarlo con una animación del modelo.
    public GameObject[] esquinas;
    public Vector3 posicion_dron;
    bool bloqueoY = false; //utilizada para bloquear la altura del dron
    int vaGancho = 0; //Variable de control para los estados de agarrar y soltar el gancho
    float  e= 1f;
    float escalaGancho = 0;
    public float dx=0, dz=0;
    //variables para verificar si se está o no agarrando objeto
    public List<GameObject> objs = cajas.objetos; //Nótese que son objetos instanciados, lo que abre posibilidades para más adelante
    public GameObject caj = cajas.caja;
    public float cajangulo,ladocaja=0.5f, colision = 0 ,M1=1, M2=5;
    Vector3 posicion;
    //finaliza variables agarrar objet
    // Start is called before the first frame update
    void Start()
    {
        escalaGancho = 0.25f;
        posicion = transform.position;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        posicion = gaancho.gameObject.GetComponent<Transform>().position; //con esta posición es que se realiza la comparación de posiciones para agarrar un objeto
        //Verificación de si se quiere bloquear la altura
        if (Input.GetMouseButtonDown(1))
        {
            if (bloqueoY == false)
            {
                bloqueoY = true;
            }
            //cuando se pregunta por si se presiona o no el mouse es menester colocarlo directamente en el Update por ello no se puso en una función aparte
            else
            {
                bloqueoY = false;
            }
        }
        //Finaliza verificación de si sequiere bloquear la altura

        golpe();
        CalculoVelocidad();
        MovimientoPersonaje();


        gravedad();
        //Empieza agarrar objeto.
        if (Input.GetMouseButtonUp(0))
        {
            GanchoObjeto();
        }

        if (vaGancho == 1)
        {
            //Si ya se presionó el botón y el estado de gancho era cero, entonces empezará a desplegar la animación del gancho
            escalaGancho += 0.3f;
            escalaGancho = Mathf.Clamp(escalaGancho, 0, 6);
            gaancho.transform.localScale = new Vector3(0.22f, escalaGancho, 0.22f);
            //se verifica si está o no tocando alguna caja
            foreach (GameObject caj in objs)
            {
                Vector3 posicion_caja = caj.gameObject.GetComponent<Transform>().position;
                //Debug.Log("La posicion de Obj es: " + caj.gameObject.GetComponent<Transform>().position + " Mientras que la de posicion caja es :" + posicion_caja );
                if (posicion.y - posicion_caja.y <= 6 && Mathf.Abs(posicion.x - posicion_caja.x) <= 1 && Mathf.Abs(posicion.z - posicion_caja.z) <= 1)
                {
                    //Debug.Log("¡La agarró! y la posicion es " + posicion_caja + " Y la del dron es :" + posicion);
                    caj.gameObject.tag = "agarrado";
                }
            }
            //Finaliza verificación de agarrar o no objeto
            Debug.Log("Está bajando");
        }
        if (vaGancho == 2)
        {
            escalaGancho -= 0.3f;
            escalaGancho = Mathf.Clamp(escalaGancho, 0, 6);
            gaancho.transform.localScale = new Vector3(0.22f, escalaGancho, 0.22f);
            if (escalaGancho <= 0)
            {
                vaGancho = 0;
            }
            Debug.Log("Está subiendo.");
            SoltarObjeto();
        }
        //Finaliza agarrar objeto.
        //empieza movimiento de la caja agarrada
        MoverAgarrado();
        //finaliza movimiento de la caja agarrada
        //Una vez hechos los posibles cambios sobre la posición del objeto, se procede, finalmente a actualizar la misma
        transform.Translate(posicion_dron, Space.Self);
        gaancho.gameObject.GetComponent<Transform>().position = transform.position;
        //finaliza actualización del objeto.
    }
    void SoltarObjeto()
    {
        foreach (GameObject caj in objs)
        {
            if (caj.gameObject.tag == "agarrado")
            {
                caj.gameObject.tag = "Untagged";
            }
        }
    }

    void MoverAgarrado()
    {
        foreach (GameObject caj in objs)
        {
            if (caj.gameObject.tag == "agarrado")
            {
                Vector3 posicion_caja = caj.gameObject.GetComponent<Transform>().position;
                caj.gameObject.GetComponent<Transform>().position = new Vector3(posicion.x, posicion.y - 1, posicion.z);
            }
        }
    }


    //Controlador estilo clic
    void GanchoObjeto()
    {
        if (vaGancho == 0)
        {
            vaGancho = 1;
        }
        else
        {
            vaGancho = 2;
        }
    }



    void CalculoVelocidad()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            ctrl++;
            if (velocidad <= 10)
            {
                velocidad += 0.1f;
            }
            else
            {
                velocidad = 10;
            }
        }
        else
        {
            if (velocidad > 0)
            {
                velocidad -= 0.1f;
            }
            else
            {
                velocidad = 0;
            }
        }
    }

    Vector3[] lados = new Vector3[4];
    void golpe() 
    {
        float def_distance = Mathf.Sqrt(2f);
        float Pdistance, i, ag, min, angulo, Vp, V1x, V1z, Vn, Vc1, Vc1x, Vc1y, Vc2, Vc2x, Vc2y;
        int id = 0;
        foreach (GameObject caj in objs)
        {
            Vector3 posicion_caja = caj.gameObject.GetComponent<Transform>().position;
            Vector3 posicion_punto;

            if (Mathf.Abs((posicion - posicion_caja).magnitude) <= Mathf.Sqrt(2f)) //capa de verificacion de colision 1
            {
                //Debug.Log(Mathf.Abs((posicion - posicion_caja).magnitude)); 
                
                for (int d = 0; d < 4; d++)
                {
                    Pdistance = (Mathf.Abs((esquinas[d].gameObject.GetComponent<Transform>().position - posicion_caja).magnitude));
                     if(Pdistance<1f)
                    {
                        colision = 1;
                    }
                     else 
                        if(Pdistance< def_distance)
                    {
                        def_distance = Pdistance;
                        id = d;
                    }
                }
                if(colision == 0)
                {   posicion_punto = esquinas[id].gameObject.GetComponent<Transform>().position;
                    cajangulo = caj.transform.rotation.eulerAngles.y;//le da el angulo en y
                    posicion_punto.x = posicion_punto.x * Mathf.Cos(cajangulo) + posicion_punto.z * Mathf.Sin(cajangulo);
                    posicion_punto.z = -posicion_punto.x * Mathf.Sin(cajangulo) + posicion_punto.z * Mathf.Cos(cajangulo);
                    dx = Mathf.Abs(posicion_punto.x - posicion_caja.x);
                    dz = Mathf.Abs(posicion_punto.z - posicion_caja.z);
                    if (posicion_punto.z < posicion_caja.z + ladocaja && posicion_punto.z > posicion_caja.z - ladocaja)
                    {
                        ag = Mathf.Atan(dz / dx);
                    }
                    else
                        ag = Mathf.Atan(dx / dz);

                    min = ladocaja * 1 / Mathf.Cos(ag);

                    if (def_distance < min)
                    {
                        colision = 1; 
                    }

                }
               
            }
        }
        if (colision == 1)
        {


            angulo = gameObject.GetComponent<Transform>().rotation.eulerAngles.y;
            Vp = velocidad;
            Vc1 = ((M1 - e * M2) / (M1 + M2)) * Vp; // velocidad resultante de la colision, en direccion del angulo (sentido opuesto)           
            Vc2 = (((1 + e) * M1) / (M1 + M2));// velocidad resultante de la colision para caja, en direccion del angulo (sentido opuesto)
            velocidad = Vc1;
            bloqueoY = false;
            colision = 0;
           

        }


    }



    float tg = 0, vy = 0.1f;
    void gravedad()
    {
        if (bloqueoY == false && ctrl == ctr0)
        {
           
            vy = vy - 9.8f * tg;
            float pos = vy * Time.deltaTime;
            posicion_dron.y = pos + posicion_dron.y;
            tg += Time.deltaTime;
            
        }
        else
        {
            vy = 0;
            tg = 0;
        }
        ctr0 = ctrl;
        if (posicion.y < 0.5f)
        {
            ctr0 = -1;

            posicion_dron.y = posicion_dron.y+ Mathf.Abs(0.4f-posicion.y);
        }


    }

    int ctrl = 0, ctr0 = -1;
    void MovimientoPersonaje()
    {
        //Empieza movimiento del dron en el plano X,Z.
        float hEntra = Input.GetAxis("Horizontal");
        float vEntra = Input.GetAxis("Vertical");
        posicion_dron = new Vector3(hEntra, 0, vEntra) * velocidad * Time.fixedDeltaTime;
        //Finaliza movimiento del dron en el plano X,Z.
        //Empieza elevación o descenso del dron (eje Y)
        if (bloqueoY == false)
        {
            if (Input.GetKey(KeyCode.Z)) //tecla Z para ir arriba
            {
                ctrl++;
                posicion_dron.y = posicion_dron.y + 0.1f;
            }
            if (Input.GetKey(KeyCode.X)) //tecla X para ir abajo
            {
                foreach (GameObject caj in objs)
                {
                    if (posicion.y >= 0.4)
                    {
                        ctrl++;
                        posicion_dron.y = posicion_dron.y - 0.01f;
                    }
                }
            }
        }
        //Finaliza elevación o descendo del dron (eje Y)
        //Empieza sobrevuelo en eje X
        if (Input.GetKey(KeyCode.Q))
        {
            posicion_dron.x = posicion_dron.x - 0.2f;
        }
        if (Input.GetKey(KeyCode.E))
        {
            posicion_dron.x = posicion_dron.x + 0.2f;
        }
        //Finaliza sobrevuelo en eje X
    }
}
